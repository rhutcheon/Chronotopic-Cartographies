# A Primer in Python

These notebooks provide a basic primer in Python, using the Natural Language Toolkit and Folium libraries to process textual and geospatial data.