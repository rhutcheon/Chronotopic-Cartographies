## A Primer in Using Graphs to Visualise Literary Texts

### Contents

- Basics with the Python programming language
- Basics with the GraphViz library
- Creating a graph of the spatial structure of a narrative